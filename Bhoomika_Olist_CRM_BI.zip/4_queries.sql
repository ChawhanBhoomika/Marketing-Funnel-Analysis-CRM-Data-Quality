﻿SELECT TOP 5 * FROM marketing_qualified_leads;
SELECT TOP 5 * FROM closed_deals;

--STEP 1
---Funnel performance by month---
SELECT
    FORMAT(m.first_contact_date, 'yyyy-MM') AS month,
    COUNT(m.mql_id) AS total_leads,
    COUNT(c.won_date) AS converted_leads
FROM marketing_qualified_leads m
LEFT JOIN closed_deals c
    ON m.mql_id = c.mql_id
GROUP BY FORMAT(m.first_contact_date, 'yyyy-MM')
ORDER BY month;


--STEP 2
----Cohort conversion (7-day & 30-day)---
SELECT
    FORMAT(m.first_contact_date, 'yyyy-MM') AS cohort_month,
    COUNT(m.mql_id) AS total_leads,
    SUM(
        CASE 
            WHEN c.won_date IS NOT NULL
             AND DATEDIFF(DAY, m.first_contact_date, c.won_date) <= 7
            THEN 1 ELSE 0
        END
    ) AS conversions_7d,
    SUM(
        CASE 
            WHEN c.won_date IS NOT NULL
             AND DATEDIFF(DAY, m.first_contact_date, c.won_date) <= 30
            THEN 1 ELSE 0
        END
    ) AS conversions_30d
FROM marketing_qualified_leads m
LEFT JOIN closed_deals c
    ON m.mql_id = c.mql_id
GROUP BY FORMAT(m.first_contact_date, 'yyyy-MM')
ORDER BY cohort_month;

--STEP 3: Time-to-conversion (SLA)
---Average time to convert by source
SELECT
    m.origin,
    AVG(DATEDIFF(DAY, m.first_contact_date, c.won_date)) AS avg_days_to_convert
FROM marketing_qualified_leads m
JOIN closed_deals c
    ON m.mql_id = c.mql_id
GROUP BY m.origin
ORDER BY avg_days_to_convert;

--STEP 4
---Top-performing channels
SELECT
    m.origin,
    COUNT(m.mql_id) AS total_leads,
    COUNT(c.won_date) AS conversions,
    CAST(COUNT(c.won_date) AS FLOAT) / COUNT(m.mql_id) AS conversion_rate
FROM marketing_qualified_leads m
LEFT JOIN closed_deals c
    ON m.mql_id = c.mql_id
GROUP BY m.origin
ORDER BY conversion_rate DESC;

--STEP 5: Data quality & anomaly checks
--1️ Conversion before lead creation (INVALID)

SELECT *
FROM marketing_qualified_leads m
JOIN closed_deals c
    ON m.mql_id = c.mql_id
WHERE c.won_date < m.first_contact_date;

--2️ Closed deals without matching leads
SELECT *
FROM closed_deals c
LEFT JOIN marketing_qualified_leads m
    ON c.mql_id = m.mql_id
WHERE m.mql_id IS NULL;

---3 Duplicate lead IDs
SELECT
    mql_id,
    COUNT(*) AS duplicate_count
FROM marketing_qualified_leads
GROUP BY mql_id
HAVING COUNT(*) > 1;

